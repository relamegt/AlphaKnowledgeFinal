import React from 'react';
import Header from '../Common/Header';
import Sidebar from '../Common/Sidebar';

const MainLayout = ({ 
  children, 
  content, 
  selectedSheet, 
  selectedSection, 
  onSheetSelect, 
  onSectionSelect,
  showSidebar = true 
}) => {
  return (
    <div className="app-layout">
      <Header />
      <div className="main-container">
        {showSidebar && (
          <Sidebar
            content={content}
            selectedSheet={selectedSheet}
            selectedSection={selectedSection}
            onSheetSelect={onSheetSelect}
            onSectionSelect={onSectionSelect}
          />
        )}
        <main className={`main-content ${!showSidebar ? 'full-width' : ''}`}>
          {children}
        </main>
      </div>
    </div>
  );
};

export default MainLayout;
