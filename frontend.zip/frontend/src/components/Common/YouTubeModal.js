import React from 'react';
import { FaTimes } from 'react-icons/fa';

const YouTubeModal = ({ videoUrl, isOpen, onClose }) => {
  if (!isOpen) return null;

  const getVideoId = (url) => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  const videoId = getVideoId(videoUrl);

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h3>Tutorial Video</h3>
          <button className="close-btn" onClick={onClose}>
            <FaTimes />
          </button>
        </div>
        <div className="video-container">
          {videoId ? (
            <iframe
              src={`https://www.youtube.com/embed/${videoId}`}
              title="Tutorial Video"
              frameBorder="0"
              allowFullScreen
            ></iframe>
          ) : (
            <p>Invalid video URL</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default YouTubeModal;
