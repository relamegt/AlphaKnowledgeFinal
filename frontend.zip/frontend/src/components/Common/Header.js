import React from 'react';
import { useAuth } from '../../context/AuthContext';
import LoginButton from '../Auth/LoginButton';

const Header = () => {
  const { user, logout } = useAuth();

  return (
    <header className="header">
      <div className="header-content">
        <div className="logo">
          <h1>Alpha Knowledge</h1>
          <span>DSA Learning Platform</span>
        </div>
        
        <div className="auth-section">
          {user ? (
            <div className="user-info">
              <img 
                src={user.profilePicture} 
                alt={user.name}
                className="profile-pic"
              />
              <span>Hello, {user.name}</span>
              <button onClick={logout} className="logout-btn">
                Logout
              </button>
            </div>
          ) : (
            <LoginButton />
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
