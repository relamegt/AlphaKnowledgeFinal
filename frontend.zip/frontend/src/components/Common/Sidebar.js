import React from 'react';
import { useProgress } from '../../hooks/useProgress';

const Sidebar = ({ content, selectedSheet, selectedSection, onSheetSelect, onSectionSelect }) => {
  const { stats } = useProgress();

  const getSheetProgress = (sheetId, sheet) => {
    const totalProblems = sheet.sections.reduce((total, section) => {
      return total + section.subsections.reduce((sectionTotal, subsection) => {
        return sectionTotal + subsection.problems.length;
      }, 0);
    }, 0);

    const completedProblems = stats.sheetStats?.[sheetId] || 0;
    return { completed: completedProblems, total: totalProblems };
  };

  return (
    <div className="sidebar">
      <div className="sidebar-content">
        <h2>DSA Sheets</h2>
        
        {content.sheets.map(sheet => {
          const progress = getSheetProgress(sheet.id, sheet);
          const percentage = progress.total > 0 ? Math.round((progress.completed / progress.total) * 100) : 0;
          
          return (
            <div key={sheet.id} className="sheet-item">
              <div 
                className={`sheet-header ${selectedSheet === sheet.id ? 'active' : ''}`}
                onClick={() => onSheetSelect(sheet.id)}
              >
                <h3>{sheet.name}</h3>
                <div className="sheet-progress">
                  <span>{progress.completed}/{progress.total}</span>
                  <div className="mini-progress-bar">
                    <div 
                      className="mini-progress-fill"
                      style={{ width: `${percentage}%` }}
                    ></div>
                  </div>
                </div>
              </div>

              {selectedSheet === sheet.id && (
                <div className="sections-list">
                  {sheet.sections.map(section => (
                    <div
                      key={section.id}
                      className={`section-item ${selectedSection === section.id ? 'active' : ''}`}
                      onClick={() => onSectionSelect(section.id)}
                    >
                      <span>{section.name}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Sidebar;
