import React from 'react';
import ProblemItem from './ProblemItem';

const SubsectionView = ({ subsection, sheetId, sectionId }) => {
  return (
    <div className="subsection">
      <h3 className="subsection-title">{subsection.name}</h3>
      <div className="problems-list">
        {subsection.problems.map(problem => (
          <ProblemItem
            key={problem.id}
            problem={problem}
            sheetId={sheetId}
            sectionId={sectionId}
            subsectionId={subsection.id}
          />
        ))}
      </div>
    </div>
  );
};

export default SubsectionView;
