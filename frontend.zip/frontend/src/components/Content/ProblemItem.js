import React, { useState } from 'react';
import { FaExternalLinkAlt, FaPlay, FaFileAlt } from 'react-icons/fa';
import { useAuth } from '../../context/AuthContext';
import { useProgress } from '../../hooks/useProgress';
import LoginButton from '../Auth/LoginButton';
import YouTubeModal from '../Common/YouTubeModal';

const ProblemItem = ({ problem, sheetId, sectionId, subsectionId }) => {
  const { user } = useAuth();
  const { toggleProblem, isProblemCompleted } = useProgress();
  const [showLoginPrompt, setShowLoginPrompt] = useState(false);
  const [showVideo, setShowVideo] = useState(false);
  const [isToggling, setIsToggling] = useState(false);

  const isCompleted = isProblemCompleted(problem.id);

  const handleCheckboxChange = async () => {
    if (!user) {
      setShowLoginPrompt(true);
      return;
    }

    setIsToggling(true);
    const success = await toggleProblem({
      problemId: problem.id,
      sheetId,
      sectionId,
      subsectionId
    });

    if (!success) {
      // Handle error - maybe show a toast notification
      console.error('Failed to toggle problem completion');
    }
    setIsToggling(false);
  };

  const getDifficultyClass = (difficulty) => {
    return `difficulty ${difficulty.toLowerCase()}`;
  };

  return (
    <div className={`problem-item ${isCompleted ? 'completed' : ''}`}>
      <div className="problem-main">
        <div className="problem-left">
          <div className="checkbox-container">
            <input
              type="checkbox"
              checked={isCompleted}
              onChange={handleCheckboxChange}
              disabled={isToggling}
              className="problem-checkbox"
            />
            {isToggling && <div className="loading-spinner"></div>}
          </div>
          <div className="problem-info">
            <h4 className="problem-title">{problem.title}</h4>
            <span className={getDifficultyClass(problem.difficulty)}>
              {problem.difficulty}
            </span>
          </div>
        </div>

        <div className="problem-actions">
          <a
            href={problem.practiceLink}
            target="_blank"
            rel="noopener noreferrer"
            className="action-btn practice-btn"
            title={`Solve on ${problem.platform}`}
          >
            <FaExternalLinkAlt />
            <span>{problem.platform}</span>
          </a>

          <button
            onClick={() => setShowVideo(true)}
            className="action-btn video-btn"
            title="Watch tutorial"
          >
            <FaPlay />
            <span>Video</span>
          </button>

          <a
            href={problem.notesLink}
            target="_blank"
            rel="noopener noreferrer"
            className="action-btn notes-btn"
            title="View notes"
          >
            <FaFileAlt />
            <span>Notes</span>
          </a>
        </div>
      </div>

      {showLoginPrompt && (
        <div className="login-prompt">
          <p>Please login to track your progress</p>
          <LoginButton onLoginPrompt={() => setShowLoginPrompt(false)} />
          <button 
            onClick={() => setShowLoginPrompt(false)}
            className="cancel-btn"
          >
            Cancel
          </button>
        </div>
      )}

      <YouTubeModal
        videoUrl={problem.youtubeLink}
        isOpen={showVideo}
        onClose={() => setShowVideo(false)}
      />
    </div>
  );
};

export default ProblemItem;
