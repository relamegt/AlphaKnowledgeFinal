import React from 'react';
import SubsectionView from './SubsectionView';
import ProgressBar from '../Common/ProgressBar';
import { useProgress } from '../../hooks/useProgress';

const SectionView = ({ section, sheetId }) => {
  const { stats } = useProgress();

  const getSectionProgress = () => {
    const totalProblems = section.subsections.reduce((total, subsection) => {
      return total + subsection.problems.length;
    }, 0);

    const completedProblems = stats.sectionStats?.[section.id] || 0;
    return { completed: completedProblems, total: totalProblems };
  };

  const progress = getSectionProgress();

  return (
    <div className="section-view">
      <div className="section-header">
        <h2>{section.name}</h2>
        <ProgressBar
          completed={progress.completed}
          total={progress.total}
          label="Section Progress"
        />
      </div>

      <div className="subsections">
        {section.subsections.map(subsection => (
          <SubsectionView
            key={subsection.id}
            subsection={subsection}
            sheetId={sheetId}
            sectionId={section.id}
          />
        ))}
      </div>
    </div>
  );
};

export default SectionView;
