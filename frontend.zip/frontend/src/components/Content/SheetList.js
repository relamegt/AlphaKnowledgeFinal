import React from 'react';
import ProgressBar from '../Common/ProgressBar';
import { useProgress } from '../../hooks/useProgress';

const SheetList = ({ content, onSheetSelect }) => {
  const { stats } = useProgress();

  const getSheetProgress = (sheetId, sheet) => {
    const totalProblems = sheet.sections.reduce((total, section) => {
      return total + section.subsections.reduce((sectionTotal, subsection) => {
        return sectionTotal + subsection.problems.length;
      }, 0);
    }, 0);

    const completedProblems = stats.sheetStats?.[sheetId] || 0;
    return { completed: completedProblems, total: totalProblems };
  };

  return (
    <div className="sheet-list">
      <h2>Choose a DSA Sheet</h2>
      <div className="sheets-grid">
        {content.sheets.map(sheet => {
          const progress = getSheetProgress(sheet.id, sheet);
          
          return (
            <div
              key={sheet.id}
              className="sheet-card"
              onClick={() => onSheetSelect(sheet.id)}
            >
              <div className="sheet-card-content">
                <h3>{sheet.name}</h3>
                <p>{sheet.description}</p>
                
                <div className="sheet-stats">
                  <div className="problems-count">
                    {progress.total} Problems
                  </div>
                  
                  <ProgressBar
                    completed={progress.completed}
                    total={progress.total}
                    label="Progress"
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SheetList;
