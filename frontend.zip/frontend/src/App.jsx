import React, { useState, useEffect } from 'react';
import { AuthProvider } from './context/AuthContext';
import MainLayout from './components/Layout/MainLayout';
import SheetList from './components/Content/SheetList';
import SectionView from './components/Content/SectionView';
import contentData from './data/content.json';
import './App.css';

function App() {
  const [content] = useState(contentData);
  const [selectedSheet, setSelectedSheet] = useState(null);
  const [selectedSection, setSelectedSection] = useState(null);
  const [currentView, setCurrentView] = useState('sheets'); // 'sheets', 'sections', 'problems'

  useEffect(() => {
    // Reset section when sheet changes
    if (selectedSheet) {
      setSelectedSection(null);
      setCurrentView('sections');
    }
  }, [selectedSheet]);

  useEffect(() => {
    // Show problems when section is selected
    if (selectedSection) {
      setCurrentView('problems');
    }
  }, [selectedSection]);

  const handleSheetSelect = (sheetId) => {
    setSelectedSheet(sheetId);
    const sheet = content.sheets.find(s => s.id === sheetId);
    if (sheet && sheet.sections.length > 0) {
      setSelectedSection(sheet.sections[0].id);
    }
  };

  const handleSectionSelect = (sectionId) => {
    setSelectedSection(sectionId);
  };

  const handleBackToSheets = () => {
    setSelectedSheet(null);
    setSelectedSection(null);
    setCurrentView('sheets');
  };

  const getCurrentSheet = () => {
    return content.sheets.find(sheet => sheet.id === selectedSheet);
  };

  const getCurrentSection = () => {
    const sheet = getCurrentSheet();
    return sheet?.sections.find(section => section.id === selectedSection);
  };

  const renderContent = () => {
    if (currentView === 'sheets') {
      return (
        <SheetList
          content={content}
          onSheetSelect={handleSheetSelect}
        />
      );
    }

    if (currentView === 'problems' && selectedSection) {
      const section = getCurrentSection();
      return (
        <div>
          <div className="breadcrumb">
            <button onClick={handleBackToSheets} className="breadcrumb-btn">
              All Sheets
            </button>
            <span> / </span>
            <span>{getCurrentSheet()?.name}</span>
            <span> / </span>
            <span>{section?.name}</span>
          </div>
          <SectionView
            section={section}
            sheetId={selectedSheet}
          />
        </div>
      );
    }

    return null;
  };

  return (
    <AuthProvider>
      <div className="App">
        <MainLayout
          content={content}
          selectedSheet={selectedSheet}
          selectedSection={selectedSection}
          onSheetSelect={handleSheetSelect}
          onSectionSelect={handleSectionSelect}
          showSidebar={currentView !== 'sheets'}
        >
          {renderContent()}
        </MainLayout>
      </div>
    </AuthProvider>
  );
}

export default App;
