import { useState, useEffect } from 'react';
import { progressAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';

export const useProgress = () => {
  const { user } = useAuth();
  const [progress, setProgress] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      fetchProgress();
      fetchStats();
    } else {
      setProgress([]);
      setStats({});
    }
  }, [user]);

  const fetchProgress = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const response = await progressAPI.getUserProgress(user.id);
      setProgress(response.data);
    } catch (error) {
      console.error('Error fetching progress:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    if (!user) return;

    try {
      const response = await progressAPI.getStats(user.id);
      setStats(response.data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const toggleProblem = async (problemData) => {
    if (!user) return false;

    try {
      const response = await progressAPI.toggleProblem(problemData);
      
      // Update local progress state
      const existingIndex = progress.findIndex(p => p.problemId === problemData.problemId);
      if (existingIndex >= 0) {
        const newProgress = [...progress];
        newProgress[existingIndex] = response.data;
        setProgress(newProgress);
      } else {
        setProgress([...progress, response.data]);
      }

      // Refresh stats
      fetchStats();
      return true;
    } catch (error) {
      console.error('Error toggling problem:', error);
      return false;
    }
  };

  const isProblemCompleted = (problemId) => {
    return progress.some(p => p.problemId === problemId && p.isCompleted);
  };

  return {
    progress,
    stats,
    loading,
    toggleProblem,
    isProblemCompleted,
    fetchProgress
  };
};
