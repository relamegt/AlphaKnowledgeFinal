import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useProgress } from '../../hooks/useProgress';
import { FaRocket, FaChartLine, FaCertificate, FaUsers, FaArrowRight, FaPlay } from 'react-icons/fa';

const Home = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { stats } = useProgress();

  const features = [
    {
      icon: FaRocket,
      title: 'Comprehensive DSA Coverage',
      description: 'Master data structures and algorithms with our carefully curated problem sets covering all important topics.'
    },
    {
      icon: FaChartLine,
      title: 'Progress Tracking',
      description: 'Track your learning journey with detailed analytics and progress visualization across different difficulty levels.'
    },
    {
      icon: FaCertificate,
      title: 'Quality Content',
      description: 'Access high-quality problems with detailed editorials, video solutions, and comprehensive notes.'
    },
    {
      icon: FaUsers,
      title: 'Structured Learning',
      description: 'Follow our structured approach to learning DSA with organized sheets and progressive difficulty levels.'
    }
  ];

  const handleGetStarted = () => {
    navigate('/sheets');
  };

  return (
    <div className="home-page">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-content">
          <div className="hero-text">
            <h1 className="hero-title">
              Master Data Structures & Algorithms with 
              <span className="hero-highlight"> Alpha Knowledge</span>
            </h1>
            <p className="hero-description">
              Your comprehensive platform for learning DSA through structured problem-solving, 
              detailed explanations, and progress tracking. Start your journey to coding excellence today.
            </p>
            
            {user && (
              <div className="user-stats">
                <div className="stat-item">
                  <span className="stat-number">{stats.totalCompleted || 0}</span>
                  <span className="stat-label">Problems Solved</span>
                </div>
                <div className="stat-item">
                  <span className="stat-number">{stats.difficultyStats?.Easy || 0}</span>
                  <span className="stat-label">Easy</span>
                </div>
                <div className="stat-item">
                  <span className="stat-number">{stats.difficultyStats?.Medium || 0}</span>
                  <span className="stat-label">Medium</span>
                </div>
                <div className="stat-item">
                  <span className="stat-number">{stats.difficultyStats?.Hard || 0}</span>
                  <span className="stat-label">Hard</span>
                </div>
              </div>
            )}

            <div className="hero-actions">
              <button 
                className="btn-primary hero-cta"
                onClick={handleGetStarted}
              >
                <FaPlay className="btn-icon" />
                {user ? 'Continue Learning' : 'Get Started'}
              </button>
              
              {!user && (
                <button 
                  className="btn-secondary"
                  onClick={() => navigate('/sheets')}
                >
                  Browse Sheets
                  <FaArrowRight className="btn-icon" />
                </button>
              )}
            </div>
          </div>

          <div className="hero-visual">
            <div className="hero-card">
              <div className="code-snippet">
                <div className="code-header">
                  <div className="code-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                  <span className="code-title">Two Sum Problem</span>
                </div>
                <div className="code-content">
                  <pre>
{`def twoSum(nums, target):
    hashMap = {}
    for i, num in enumerate(nums):
        complement = target - num
        if complement in hashMap:
            return [hashMap[complement], i]
        hashMap[num] = i
    return []`}
                  </pre>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section">
        <div className="section-content">
          <div className="section-header">
            <h2>Why Choose Alpha Knowledge?</h2>
            <p>Everything you need to excel in data structures and algorithms</p>
          </div>
          
          <div className="features-grid">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="feature-card">
                  <div className="feature-icon">
                    <Icon />
                  </div>
                  <h3 className="feature-title">{feature.title}</h3>
                  <p className="feature-description">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="cta-content">
          <h2>Ready to Start Your DSA Journey?</h2>
          <p>Join thousands of learners who are mastering algorithms and data structures</p>
          <button 
            className="btn-primary cta-button"
            onClick={handleGetStarted}
          >
            <FaRocket className="btn-icon" />
            Start Learning Now
          </button>
        </div>
      </section>
    </div>
  );
};

export default Home;
