import React from 'react';
import { createPortal } from 'react-dom';
import { FaTimes, FaYoutube } from 'react-icons/fa';

const YouTubeModal = ({ videoUrl, isOpen, onClose, problemName }) => {
  if (!isOpen) return null;

  const getVideoId = (url) => {
    if (!url) return null;
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  const videoId = getVideoId(videoUrl);

  return createPortal(
    <div 
      className="youtube-modal-overlay"
      onClick={onClose}
    >
      {/* Close Button */}
      <button
        onClick={onClose}
        className="youtube-modal-close"
      >
        <FaTimes />
      </button>

      {/* Video Container */}
      <div 
        className="youtube-modal-container"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header with Problem Name */}
        <div className="youtube-modal-header">
          <div className="youtube-modal-title">
            <FaYoutube className="youtube-icon" />
            <div className="title-text">
              <h3>Editorial Video</h3>
              {problemName && (
                <p className="problem-name">{problemName}</p>
              )}
            </div>
          </div>
        </div>

        {/* Video Content */}
        <div className="youtube-modal-content">
          {videoId ? (
            <iframe
              src={`https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`}
              title={`Editorial Video${problemName ? ` - ${problemName}` : ''}`}
              className="youtube-iframe"
              allowFullScreen
              allow="autoplay; encrypted-media"
            />
          ) : (
            <div className="youtube-error">
              <div className="error-content">
                <FaYoutube className="error-icon" />
                <h4>Invalid Video URL</h4>
                <p>The video URL provided is not valid or accessible.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>,
    document.body
  );
};

export default YouTubeModal;
