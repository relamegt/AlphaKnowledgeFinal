import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import LoginButton from '../Auth/LoginButton';
import { FaSun, FaMoon, FaBars, FaTimes, FaHome, FaList, FaEnvelope } from 'react-icons/fa';

const Header = () => {
  const { user, logout } = useAuth();
  const { theme, toggleTheme, isDark } = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navigationItems = [
    { path: '/', label: 'Home', icon: FaHome },
    { path: '/sheets', label: 'Sheets', icon: FaList },
    { path: '/contact', label: 'Contact Us', icon: FaEnvelope }
  ];

  const handleNavigation = (path) => {
    navigate(path);
    setIsMobileMenuOpen(false);
  };

  const handleLogout = () => {
    logout();
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="header">
      <div className="header-content">
        {/* Logo Section */}
        <div 
          className="logo" 
          onClick={() => handleNavigation('/')}
          style={{ cursor: 'pointer' }}
        >
          <div className="logo-icon">
            <span className="logo-symbol">α</span>
          </div>
          <div className="logo-text">
            <h1>Alpha Knowledge</h1>
            <span>DSA Learning Platform</span>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="desktop-nav">
          <ul className="nav-list">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              return (
                <li key={item.path}>
                  <button
                    className={`nav-link ${location.pathname === item.path ? 'active' : ''}`}
                    onClick={() => handleNavigation(item.path)}
                  >
                    <Icon className="nav-icon" />
                    {item.label}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Right Section */}
        <div className="header-right">
          {/* Theme Toggle */}
          <button 
            className="theme-toggle-btn"
            onClick={toggleTheme}
            title={`Switch to ${isDark ? 'light' : 'dark'} mode`}
          >
            {isDark ? <FaSun /> : <FaMoon />}
          </button>

          {/* User Section */}
          <div className="auth-section">
            {user ? (
              <div className="user-menu">
                <div className="user-info">
                  <img 
                    src={user.profilePicture} 
                    alt={user.name}
                    className="profile-pic"
                  />
                  <div className="user-details">
                    <span className="user-name">Hello, {user.name.split(' ')[0]}</span>
                    <span className="user-email">{user.email}</span>
                  </div>
                </div>
                <button onClick={handleLogout} className="logout-btn">
                  Logout
                </button>
              </div>
            ) : (
              <LoginButton />
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            className="mobile-menu-toggle"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <FaTimes /> : <FaBars />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMobileMenuOpen && (
        <div className="mobile-nav">
          <div className="mobile-nav-content">
            <ul className="mobile-nav-list">
              {navigationItems.map((item) => {
                const Icon = item.icon;
                return (
                  <li key={item.path}>
                    <button
                      className={`mobile-nav-link ${location.pathname === item.path ? 'active' : ''}`}
                      onClick={() => handleNavigation(item.path)}
                    >
                      <Icon className="nav-icon" />
                      {item.label}
                    </button>
                  </li>
                );
              })}
            </ul>

            {/* Mobile Auth Section */}
            <div className="mobile-auth">
              {user ? (
                <div className="mobile-user-section">
                  <div className="mobile-user-info">
                    <img 
                      src={user.profilePicture} 
                      alt={user.name}
                      className="profile-pic"
                    />
                    <div>
                      <div className="user-name">{user.name}</div>
                      <div className="user-email">{user.email}</div>
                    </div>
                  </div>
                  <button onClick={handleLogout} className="mobile-logout-btn">
                    Logout
                  </button>
                </div>
              ) : (
                <div className="mobile-login">
                  <LoginButton />
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
