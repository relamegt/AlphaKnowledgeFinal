import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { FaGoogle } from 'react-icons/fa';

const LoginButton = ({ onLoginPrompt = null }) => {
  const { login } = useAuth();

  const handleLogin = () => {
    if (onLoginPrompt) {
      onLoginPrompt();
    }
    login();
  };

  return (
    <button className="login-btn" onClick={handleLogin}>
      <FaGoogle className="google-icon" />
      Login with Google
    </button>
  );
};

export default LoginButton;
