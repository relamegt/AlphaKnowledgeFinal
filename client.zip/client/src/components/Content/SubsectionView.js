import React, { useState } from 'react';
import { useProgress } from '../../hooks/useProgress';
import ProblemItem from './ProblemItem';

const SubsectionView = ({ subsection, sheetId, sectionId, index }) => {
  const { stats } = useProgress();
  const [isExpanded, setIsExpanded] = useState(false);

  if (!subsection) {
    console.error('SubsectionView: subsection is undefined');
    return null;
  }

  if (!Array.isArray(subsection.problems)) {
    console.error('SubsectionView: subsection.problems is not an array', subsection);
    return null;
  }

  const getSubsectionProgress = () => {
    const totalProblems = subsection.problems.length;
    const completedProblems = stats?.subsectionStats?.[subsection.id] || 0;
    return { completed: completedProblems, total: totalProblems };
  };

  const progress = getSubsectionProgress();
  const percentage = progress.total > 0 ? Math.round((progress.completed / progress.total) * 100) : 0;

  return (
    <div className="subsection-container" style={{ 
      margin: '0',
      padding: '0',
      border: 'none',
      background: 'transparent',
      width: '100%',
      boxSizing: 'border-box'
    }}>
      {/* Subsection Header - Remove borderBottom */}
      <div 
        className="subsection-header"
        onClick={() => setIsExpanded(!isExpanded)}
        style={{
          cursor: 'pointer',
          padding: '16px 24px',
          backgroundColor: 'transparent',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          // REMOVED: borderBottom property completely
          transition: 'all 0.3s ease',
          position: 'relative',
          borderTop: 'none',
          border: 'none', // Ensure no borders at all
          margin: '0',
          marginTop: '0',
          paddingTop: index === 0 ? '16px' : '16px',
          paddingLeft: '60px',
          width: '100%',
          boxSizing: 'border-box'
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = 'rgba(59, 130, 246, 0.02)';
          e.currentTarget.style.paddingLeft = '65px';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = 'transparent';
          e.currentTarget.style.paddingLeft = '60px';
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{
            width: '24px',
            height: '24px',
            borderRadius: '6px',
            background: isExpanded ? 
              'linear-gradient(135deg, #3b82f6, #2563eb)' : 
              'linear-gradient(135deg, #f1f5f9, #e2e8f0)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: isExpanded ? 'white' : '#64748b',
            fontSize: '10px',
            fontWeight: '600',
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            transform: isExpanded ? 'rotate(90deg)' : 'rotate(0deg)',
            boxShadow: isExpanded ? '0 2px 8px rgba(59, 130, 246, 0.3)' : 'none'
          }}>
            ▶
          </div>
          
          <div>
            <h3 style={{ 
              margin: '0 0 2px 0', 
              fontSize: '16px',
              fontWeight: '500',
              color: '#1e293b',
              letterSpacing: '-0.025em'
            }}>
              {subsection.name}
            </h3>
            <div style={{
              fontSize: '12px',
              color: '#64748b',
              fontWeight: '400'
            }}>
              {progress.total} problems
            </div>
          </div>
        </div>
        
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '12px'
        }}>
          <div style={{
            position: 'relative',
            width: '36px',
            height: '36px',
            background: `conic-gradient(
              ${percentage === 100 ? '#22c55e' : '#3b82f6'} 0deg ${percentage * 3.6}deg,
              #f1f5f9 ${percentage * 3.6}deg 360deg
            )`,
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: percentage === 100 ? 
              '0 4px 12px rgba(34, 197, 94, 0.3)' : 
              '0 2px 8px rgba(59, 130, 246, 0.2)'
          }}>
            <div style={{
              width: '28px',
              height: '28px',
              borderRadius: '50%',
              backgroundColor: 'white',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '9px',
              fontWeight: '700',
              color: percentage === 100 ? '#22c55e' : '#3b82f6',
              textAlign: 'center',
              lineHeight: '1'
            }}>
              <div>
                <div style={{ fontSize: '10px' }}>{progress.completed}</div>
                <div style={{ fontSize: '7px', opacity: 0.7 }}>/{progress.total}</div>
              </div>
            </div>

            {percentage === 100 && progress.total > 0 && (
              <div style={{
                position: 'absolute',
                top: '-3px',
                right: '-3px',
                width: '14px',
                height: '14px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #22c55e, #16a34a)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: '0 2px 6px rgba(34, 197, 94, 0.4)',
                border: '2px solid white'
              }}>
                <span style={{
                  fontSize: '7px',
                  color: 'white',
                  fontWeight: '700'
                }}>✓</span>
              </div>
            )}
          </div>

          <div style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'flex-end'
          }}>
            <div style={{
              fontSize: '12px',
              fontWeight: '700',
              color: '#1e293b',
              lineHeight: '1.2'
            }}>
              {percentage}%
            </div>
            <div style={{
              fontSize: '9px',
              color: percentage === 100 ? '#22c55e' : '#64748b',
              fontWeight: '600',
              textTransform: 'uppercase',
              letterSpacing: '0.05em'
            }}>
              {percentage === 100 ? 'DONE' : 'PROGRESS'}
            </div>
          </div>
        </div>
      </div>

      {/* Problems Table - Clean transition with no border */}
      {isExpanded && (
        <div className="subsection-content" style={{ 
          padding: '0',
          background: 'rgba(248, 250, 252, 0.3)',
          margin: '0',
          marginTop: '0', // No gap between header and content
          paddingTop: '8px', // Small top padding for visual separation
          paddingLeft: '80px',
          paddingRight: '20px',
          paddingBottom: '16px',
          width: '100%',
          boxSizing: 'border-box'
        }}>
          <div className="problems-table-container" style={{
            borderRadius: '12px',
            overflow: 'hidden',
            margin: '0',
            marginTop: '0',
            width: '100%',
            maxWidth: 'calc(100% - 40px)',
            boxSizing: 'border-box'
          }}>
            <table style={{ 
              width: '100%', 
              borderCollapse: 'collapse',
              fontSize: '14px',
              backgroundColor: 'white',
              margin: '0',
              marginTop: '0',
              tableLayout: 'fixed'
            }}>
              <thead>
                <tr style={{ 
                  background: 'linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)',
                  borderBottom: '2px solid #e2e8f0'
                }}>
                  <th style={{ 
                    padding: '12px 16px', 
                    textAlign: 'left', 
                    fontWeight: '600', 
                    color: '#1e293b',
                    fontSize: '13px',
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                    width: '10%'
                  }}>Status</th>
                  <th style={{ 
                    padding: '12px 16px', 
                    textAlign: 'left', 
                    fontWeight: '600', 
                    color: '#1e293b',
                    fontSize: '13px',
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                    width: '25%'
                  }}>Problem</th>
                  <th style={{ 
                    padding: '12px 16px', 
                    textAlign: 'center', 
                    fontWeight: '600', 
                    color: '#1e293b',
                    fontSize: '13px',
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                    width: '15%'
                  }}>Editorial</th>
                  <th style={{ 
                    padding: '12px 16px', 
                    textAlign: 'center', 
                    fontWeight: '600', 
                    color: '#1e293b',
                    fontSize: '13px',
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                    width: '15%'
                  }}>Notes</th>
                  <th style={{ 
                    padding: '12px 16px', 
                    textAlign: 'center', 
                    fontWeight: '600', 
                    color: '#1e293b',
                    fontSize: '13px',
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                    width: '15%'
                  }}>Practice</th>
                  <th style={{ 
                    padding: '12px 16px', 
                    textAlign: 'center', 
                    fontWeight: '600', 
                    color: '#1e293b',
                    fontSize: '13px',
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                    width: '20%'
                  }}>Difficulty</th>
                </tr>
              </thead>
              <tbody>
                {subsection.problems.map((problem, problemIndex) => (
                  <ProblemItem
                    key={problem.id}
                    problem={problem}
                    sheetId={sheetId}
                    sectionId={sectionId}
                    subsectionId={subsection.id}
                    index={problemIndex}
                  />
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default SubsectionView;
