import React from 'react';
import { useNavigate } from 'react-router-dom';
import ProgressBar from '../Common/ProgressBar';
import { useProgress } from '../../hooks/useProgress';

const SheetList = ({ content }) => {
  const navigate = useNavigate();
  const { stats } = useProgress();

  const getSheetProgress = (sheetId, sheet) => {
    const totalProblems = sheet.sections.reduce((total, section) => {
      return total + section.subsections.reduce((sectionTotal, subsection) => {
        return sectionTotal + subsection.problems.length;
      }, 0);
    }, 0);

    const completedProblems = stats.sheetStats?.[sheetId] || 0;
    return { completed: completedProblems, total: totalProblems };
  };

  const handleSheetSelect = (sheetId) => {
    navigate(`/sheet/${sheetId}`);
  };

  return (
    <div className="sheet-list" style={{
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '20px'
    }}>
      <h2 style={{
        textAlign: 'center',
        marginBottom: '32px',
        fontSize: '28px',
        fontWeight: '700',
        color: '#1e293b'
      }}>
        Choose a DSA Sheet
      </h2>
      
      <div className="sheets-grid" style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))',
        gap: '24px'
      }}>
        {content.sheets.map(sheet => {
          const progress = getSheetProgress(sheet.id, sheet);
          const percentage = progress.total > 0 ? Math.round((progress.completed / progress.total) * 100) : 0;
          
          return (
            <div
              key={sheet.id}
              className="sheet-card"
              onClick={() => handleSheetSelect(sheet.id)}
              style={{
                background: '#ffffff',
                border: '1px solid #e2e8f0',
                borderRadius: '12px',
                padding: '24px',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.08)',
                height: 'auto',
                minHeight: '220px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                position: 'relative',
                overflow: 'hidden'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-4px)';
                e.currentTarget.style.boxShadow = '0 8px 25px rgba(0, 0, 0, 0.15)';
                e.currentTarget.style.borderColor = '#3b82f6';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.08)';
                e.currentTarget.style.borderColor = '#e2e8f0';
              }}
            >
              <div className="sheet-card-content">
                {/* Sheet Header */}
                <div style={{ marginBottom: '16px' }}>
                  <h3 style={{
                    margin: '0 0 8px 0',
                    fontSize: '20px',
                    fontWeight: '600',
                    color: '#1e293b',
                    lineHeight: '1.3'
                  }}>
                    {sheet.name}
                  </h3>
                  
                  <p style={{
                    margin: '0',
                    color: '#64748b',
                    fontSize: '14px',
                    lineHeight: '1.5',
                    height: '40px',
                    overflow: 'hidden',
                    display: '-webkit-box',
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: 'vertical'
                  }}>
                    {sheet.description || `Master data structures and algorithms with ${progress.total} carefully curated problems`}
                  </p>
                </div>

                {/* Sheet Statistics */}
                <div className="sheet-stats" style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px'
                }}>
                  {/* Problems Count and Sections */}
                  <div style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}>
                    <div className="problems-count" style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px'
                    }}>
                      <span style={{
                        background: '#f1f5f9',
                        color: '#475569',
                        padding: '4px 8px',
                        borderRadius: '6px',
                        fontSize: '12px',
                        fontWeight: '500'
                      }}>
                        📊 {progress.total} Problems
                      </span>
                      <span style={{
                        background: '#eff6ff',
                        color: '#2563eb',
                        padding: '4px 8px',
                        borderRadius: '6px',
                        fontSize: '12px',
                        fontWeight: '500'
                      }}>
                        📁 {sheet.sections.length} Sections
                      </span>
                    </div>
                  </div>

                  {/* Progress Section */}
                  <div style={{
                    background: '#f8fafc',
                    padding: '12px',
                    borderRadius: '8px',
                    border: '1px solid #f1f5f9'
                  }}>
                    <div style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      marginBottom: '8px'
                    }}>
                      <span style={{
                        fontSize: '13px',
                        fontWeight: '500',
                        color: '#475569'
                      }}>
                        
                      </span>
                      {/* <span style={{
                        fontSize: '13px',
                        fontWeight: '600',
                        color: percentage === 100 ? '#059669' : '#3b82f6'
                      }}>
                        {progress.completed} / {progress.total} ({percentage}%)
                      </span> */}
                    </div>
                    
                    <ProgressBar
                      completed={progress.completed}
                      total={progress.total}
                      label="Your Progress"
                      height="6px"
                      backgroundColor="#e2e8f0"
                      completedColor={percentage === 100 ? "#22c55e" : "#3b82f6"}
                    />
                  </div>
                </div>
              </div>

              {/* Action Indicator */}
              <div style={{
                position: 'absolute',
                top: '16px',
                right: '16px',
                color: '#94a3b8',
                fontSize: '18px',
                transition: 'all 0.2s ease'
              }}>
                →
              </div>

              {/* Completion Badge */}
              {percentage === 100 && (
                <div style={{
                  position: 'absolute',
                  top: '-8px',
                  right: '-8px',
                  background: 'linear-gradient(45deg, #22c55e, #16a34a)',
                  color: 'white',
                  padding: '4px 12px',
                  borderRadius: '12px',
                  fontSize: '10px',
                  fontWeight: '600',
                  transform: 'rotate(12deg)',
                  boxShadow: '0 2px 4px rgba(34, 197, 94, 0.3)'
                }}>
                  COMPLETED ✓
                </div>
              )}
            </div>
          );
        })}
      </div>

      
    </div>
  );
};

export default SheetList;
