import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { FaExternalLinkAlt, FaPlay, FaCheckCircle, FaTimes, FaLock, FaFileAlt } from 'react-icons/fa';
import { useAuth } from '../../context/AuthContext';
import { useProgress } from '../../hooks/useProgress';
import LoginButton from '../Auth/LoginButton';
import YouTubeModal from '../Common/YouTubeModal';

const ProblemItem = ({ problem, sheetId, sectionId, subsectionId, index }) => {
  const { user } = useAuth();
  const { toggleProblem, isProblemCompleted, refreshStats } = useProgress();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showVideo, setShowVideo] = useState(false);
  const [isToggling, setIsToggling] = useState(false);
  const [localCompleted, setLocalCompleted] = useState(false);

  const isCompleted = isProblemCompleted(problem.id) || localCompleted;

  // Update local state when global state changes
  useEffect(() => {
    setLocalCompleted(isProblemCompleted(problem.id));
  }, [isProblemCompleted, problem.id]);

  // ✨ OPTIMIZED: Instant UI toggle with optimistic updates
  const handleCheckboxChange = async () => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }

    // ✨ INSTANT: Update UI immediately
    const newCompletedState = !isCompleted;
    setLocalCompleted(newCompletedState);
    setIsToggling(true);

    try {
      const success = await toggleProblem({
        problemId: problem.id,
        sheetId,
        sectionId,
        subsectionId,
        difficulty: problem.difficulty
      });

      if (!success) {
        // ✨ ROLLBACK: Revert UI if API call failed
        setLocalCompleted(!newCompletedState);
      }
      // Note: We don't call refreshStats() here anymore as it's handled in context
    } catch (error) {
      console.error('Failed to toggle problem completion:', error);
      // ✨ ROLLBACK: Revert UI on error
      setLocalCompleted(!newCompletedState);
    } finally {
      setIsToggling(false);
    }
  };

  // ✨ OPTIMIZED: Instant login success handling
  const handleLoginSuccess = async (userData) => {
    try {
      setShowAuthModal(false);
      console.log('Login successful, userData:', userData);
      
      // ✨ INSTANT: Update UI immediately
      setLocalCompleted(true);
      setIsToggling(true);
      
      try {
        const success = await toggleProblem({
          problemId: problem.id,
          sheetId,
          sectionId,
          subsectionId,
          difficulty: problem.difficulty
        });

        if (!success) {
          console.error('Failed to toggle problem - API returned false');
          // ✨ ROLLBACK: Revert if API failed
          setLocalCompleted(false);
        } else {
          console.log('Problem marked as completed successfully');
        }
      } catch (error) {
        console.error('Failed to toggle problem after login:', error);
        // ✨ ROLLBACK: Revert on error
        setLocalCompleted(false);
      } finally {
        setIsToggling(false);
      }
      
    } catch (error) {
      console.error('Error in handleLoginSuccess:', error);
      setIsToggling(false);
    }
  };

  const getDifficultyConfig = (difficulty) => {
    switch(difficulty?.toLowerCase()) {
      case 'easy': 
        return {
          color: '#22c55e',
          background: 'rgba(34, 197, 94, 0.1)',
          border: 'rgba(34, 197, 94, 0.3)',
          icon: '🟢'
        };
      case 'medium': 
        return {
          color: '#f59e0b',
          background: 'rgba(245, 158, 11, 0.1)',
          border: 'rgba(245, 158, 11, 0.3)',
          icon: '🟡'
        };
      case 'hard': 
        return {
          color: '#ef4444',
          background: 'rgba(239, 68, 68, 0.1)',
          border: 'rgba(239, 68, 68, 0.3)',
          icon: '🔴'
        };
      default: 
        return {
          color: '#64748b',
          background: 'rgba(100, 116, 139, 0.1)',
          border: 'rgba(100, 116, 139, 0.3)',
          icon: '⚪'
        };
    }
  };

  const difficultyConfig = getDifficultyConfig(problem.difficulty);

  // Full-Screen Authentication Modal Component
  const AuthModal = () => {
    if (!showAuthModal) return null;

    return createPortal(
      <div 
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          width: '100vw',
          height: '100vh',
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          backdropFilter: 'blur(15px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 99999,
          animation: 'fadeIn 0.4s ease-out',
          padding: '20px',
          boxSizing: 'border-box'
        }}
        onClick={(e) => {
          if (e.target === e.currentTarget) {
            setShowAuthModal(false);
          }
        }}
      >
        <div 
          style={{
            background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.98) 0%, rgba(255, 255, 255, 0.95) 100%)',
            backdropFilter: 'blur(20px)',
            borderRadius: '32px',
            padding: '48px',
            maxWidth: '560px',
            width: '100%',
            maxHeight: '90vh',
            overflowY: 'auto',
            position: 'relative',
            border: '1px solid rgba(255, 255, 255, 0.3)',
            boxShadow: '0 32px 80px rgba(0, 0, 0, 0.4)',
            animation: 'slideInScale 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
            textAlign: 'center'
          }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Enhanced Background Pattern */}
          <div style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            background: `
              radial-gradient(circle at 25% 25%, rgba(102, 126, 234, 0.1) 0%, transparent 50%),
              radial-gradient(circle at 75% 75%, rgba(118, 75, 162, 0.1) 0%, transparent 50%),
              radial-gradient(circle at 50% 50%, rgba(255, 255, 255, 0.05) 0%, transparent 70%)
            `,
            borderRadius: '32px',
            zIndex: 0
          }} />

          {/* Close Button */}
          <button
            onClick={() => setShowAuthModal(false)}
            style={{
              position: 'absolute',
              top: '20px',
              right: '20px',
              width: '40px',
              height: '40px',
              borderRadius: '12px',
              border: 'none',
              background: 'rgba(100, 116, 139, 0.1)',
              color: '#64748b',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
              zIndex: 2
            }}
            onMouseEnter={(e) => {
              e.target.style.background = 'rgba(239, 68, 68, 0.15)';
              e.target.style.color = '#ef4444';
              e.target.style.transform = 'scale(1.1)';
            }}
            onMouseLeave={(e) => {
              e.target.style.background = 'rgba(100, 116, 139, 0.1)';
              e.target.style.color = '#64748b';
              e.target.style.transform = 'scale(1)';
            }}
          >
            <FaTimes size={16} />
          </button>

          {/* Modal content */}
          <div style={{ position: 'relative', zIndex: 1 }}>
            <div style={{ marginBottom: '40px' }}>
              <div style={{
                width: '100px',
                height: '100px',
                margin: '0 auto 24px auto',
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                borderRadius: '24px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: '0 12px 40px rgba(102, 126, 234, 0.4)',
                animation: 'float 3s ease-in-out infinite'
              }}>
                <FaLock size={40} color="white" />
              </div>

              <h2 style={{
                margin: '0 0 12px 0',
                fontSize: '1.8rem',
                fontWeight: '700',
                color: '#1e293b',
                letterSpacing: '-0.025em'
              }}>
                Sign In Required
              </h2>
              
              <p style={{
                margin: '0',
                color: '#64748b',
                fontSize: '1.1rem',
                lineHeight: '1.7',
                maxWidth: '400px',
                margin: '0 auto'
              }}>
                Sign in to mark this problem as completed and track your progress
              </p>
            </div>

            <div style={{
              background: 'rgba(248, 250, 252, 0.9)',
              backdropFilter: 'blur(10px)',
              borderRadius: '20px',
              padding: '24px',
              marginBottom: '40px',
              border: '1px solid rgba(226, 232, 240, 0.6)',
              boxShadow: '0 4px 16px rgba(0, 0, 0, 0.05)'
            }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '16px',
                marginBottom: '12px',
                flexWrap: 'wrap'
              }}>
                <div style={{
                  background: 'linear-gradient(135deg, #f8fafc, #f1f5f9)',
                  padding: '8px 16px',
                  borderRadius: '12px',
                  border: '1px solid rgba(226, 232, 240, 0.8)'
                }}>
                  <span style={{ 
                    fontSize: '1.1rem', 
                    fontWeight: '700', 
                    color: '#1e293b'
                  }}>
                    {problem.title}
                  </span>
                </div>
                
                <div style={{
                  background: difficultyConfig.background,
                  color: difficultyConfig.color,
                  border: `1px solid ${difficultyConfig.border}`,
                  padding: '8px 16px',
                  borderRadius: '12px',
                  fontSize: '12px',
                  fontWeight: '700',
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px'
                }}>
                  <span>{difficultyConfig.icon}</span>
                  {problem.difficulty}
                </div>
              </div>
              <p style={{
                margin: '0',
                color: '#64748b',
                fontSize: '1rem',
                lineHeight: '1.6'
              }}>
                Once signed in, this problem will be automatically marked as completed!
              </p>
            </div>

            <div style={{
              display: 'flex',
              gap: '20px',
              justifyContent: 'center',
              flexWrap: 'wrap',
              marginBottom: '32px'
            }}>
              <LoginButton 
                onLoginSuccess={handleLoginSuccess}
                onLoginPrompt={() => {}}
                style={{
                  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                  color: 'white',
                  border: 'none',
                  padding: '16px 32px',
                  borderRadius: '16px',
                  fontSize: '16px',
                  fontWeight: '700',
                  cursor: 'pointer',
                  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                  boxShadow: '0 8px 24px rgba(102, 126, 234, 0.4)',
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em',
                  minWidth: '140px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px'
                }}
                onMouseEnter={(e) => {
                  e.target.style.transform = 'translateY(-2px)';
                  e.target.style.boxShadow = '0 12px 32px rgba(102, 126, 234, 0.5)';
                }}
                onMouseLeave={(e) => {
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.boxShadow = '0 8px 24px rgba(102, 126, 234, 0.4)';
                }}
              />
              
              <button 
                onClick={() => setShowAuthModal(false)}
                style={{
                  background: 'transparent',
                  color: '#64748b',
                  border: '2px solid rgba(100, 116, 139, 0.3)',
                  padding: '16px 32px',
                  borderRadius: '16px',
                  fontSize: '16px',
                  fontWeight: '700',
                  cursor: 'pointer',
                  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em',
                  minWidth: '140px'
                }}
                onMouseEnter={(e) => {
                  e.target.style.borderColor = 'rgba(100, 116, 139, 0.6)';
                  e.target.style.color = '#1e293b';
                  e.target.style.background = 'rgba(100, 116, 139, 0.05)';
                  e.target.style.transform = 'translateY(-2px)';
                }}
                onMouseLeave={(e) => {
                  e.target.style.borderColor = 'rgba(100, 116, 139, 0.3)';
                  e.target.style.color = '#64748b';
                  e.target.style.background = 'transparent';
                  e.target.style.transform = 'translateY(0)';
                }}
              >
                Maybe Later
              </button>
            </div>

            <div style={{
              background: 'rgba(34, 197, 94, 0.08)',
              backdropFilter: 'blur(10px)',
              borderRadius: '16px',
              padding: '20px',
              border: '1px solid rgba(34, 197, 94, 0.15)'
            }}>
              <p style={{
                margin: '0',
                color: '#059669',
                fontSize: '0.95rem',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                flexWrap: 'wrap'
              }}>
                <span style={{ fontSize: '1.2rem' }}>✨</span>
                <span>Sign in with Google in seconds and start tracking your progress!</span>
                <span style={{ fontSize: '1.2rem' }}>🚀</span>
              </p>
            </div>
          </div>
        </div>

        <style jsx>{`
          @keyframes fadeIn {
            from { 
              opacity: 0; 
            }
            to { 
              opacity: 1; 
            }
          }
          @keyframes slideInScale {
            from {
              opacity: 0;
              transform: translateY(40px) scale(0.9);
            }
            to {
              opacity: 1;
              transform: translateY(0) scale(1);
            }
          }
          @keyframes float {
            0%, 100% {
              transform: translateY(0px);
            }
            50% {
              transform: translateY(-10px);
            }
          }
        `}</style>
      </div>,
      document.body
    );
  };

  return (
    <>
      <tr style={{ 
        border: '1px solid rgba(226, 232, 240, 0.3)',
        backgroundColor: isCompleted ? 
          'linear-gradient(135deg, rgba(34, 197, 94, 0.03) 0%, rgba(255, 255, 255, 0.95) 100%)' : 
          index % 2 === 0 ? '#ffffff' : 'rgba(248, 250, 252, 0.5)',
        position: 'relative',
        transition: 'all 0.2s ease' // ✨ Faster transition
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = 'rgba(226, 232, 240, 0.5)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = 'rgba(226, 232, 240, 0.3)';
      }}
      >
        {/* ✨ OPTIMIZED: Modern Status Checkbox with instant feedback */}
        <td style={{ 
          padding: '12px 16px', 
          textAlign: 'center',
          borderRight: '1px solid rgba(226, 232, 240, 0.2)'
        }}>
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            position: 'relative'
          }}>
            <div 
              onClick={handleCheckboxChange}
              style={{
                width: '24px',
                height: '24px',
                borderRadius: '6px',
                border: isCompleted ? 'none' : '2px solid #e2e8f0',
                background: isCompleted ? 
                  'linear-gradient(135deg, #22c55e, #16a34a)' : 
                  'white',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: isToggling ? 'not-allowed' : 'pointer',
                transition: 'all 0.15s cubic-bezier(0.4, 0, 0.2, 1)', // ✨ Faster transition
                boxShadow: isCompleted ? 
                  '0 4px 12px rgba(34, 197, 94, 0.3)' : 
                  '0 2px 4px rgba(0, 0, 0, 0.05)',
                opacity: isToggling ? 0.7 : 1,
                transform: isToggling ? 'scale(0.95)' : 'scale(1)' // ✨ Visual feedback during toggle
              }}
              onMouseEnter={(e) => {
                if (!isCompleted && !isToggling) {
                  e.target.style.borderColor = '#3b82f6';
                  e.target.style.transform = 'scale(1.05)'; // ✨ Smaller hover effect for speed
                }
              }}
              onMouseLeave={(e) => {
                if (!isCompleted && !isToggling) {
                  e.target.style.borderColor = '#e2e8f0';
                  e.target.style.transform = 'scale(1)';
                }
              }}
            >
              {isCompleted && (
                <FaCheckCircle 
                  size={14} 
                  color="white"
                  style={{ animation: 'checkmark 0.2s ease-in-out' }} // ✨ Faster animation
                />
              )}
            </div>
            {isToggling && (
              <div style={{
                position: 'absolute',
                width: '16px', // ✨ Smaller spinner
                height: '16px',
                border: '2px solid #3b82f6',
                borderTop: '2px solid transparent',
                borderRadius: '50%',
                animation: 'spin 0.8s linear infinite' // ✨ Faster spin
              }} />
            )}
          </div>
        </td>

        {/* Enhanced Problem Name */}
        <td style={{ 
          padding: '12px 16px',
          fontWeight: '600',
          color: isCompleted ? '#22c55e' : '#1e293b',
          fontSize: '15px',
          borderRight: '1px solid rgba(226, 232, 240, 0.2)',
          transition: 'color 0.15s ease' // ✨ Smooth color transition
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            {problem.title || '-'}
            {isCompleted && (
              <span style={{
                background: 'linear-gradient(135deg, #22c55e, #16a34a)',
                color: 'white',
                padding: '2px 6px',
                borderRadius: '4px',
                fontSize: '10px',
                fontWeight: '700',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
                animation: 'fadeInScale 0.3s ease-out' // ✨ Smooth appearance
              }}>
                SOLVED
              </span>
            )}
          </div>
        </td>

        {/* Modern Editorial Button */}
        <td style={{ 
          padding: '12px 16px', 
          textAlign: 'center',
          borderRight: '1px solid rgba(226, 232, 240, 0.2)'
        }}>
          {problem.youtubeLink ? (
            <button
              onClick={() => setShowVideo(true)}
              style={{
                background: 'linear-gradient(135deg, #dc2626, #b91c1c)',
                color: 'white',
                padding: '8px 16px',
                borderRadius: '10px',
                border: 'none',
                cursor: 'pointer',
                fontSize: '13px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                margin: '0 auto',
                transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)', // ✨ Faster transition
                boxShadow: '0 4px 12px rgba(220, 38, 38, 0.3)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em'
              }}
              title="Watch editorial video"
              onMouseEnter={(e) => {
                e.target.style.transform = 'translateY(-2px)';
                e.target.style.boxShadow = '0 8px 20px rgba(220, 38, 38, 0.4)';
              }}
              onMouseLeave={(e) => {
                e.target.style.transform = 'translateY(0)';
                e.target.style.boxShadow = '0 4px 12px rgba(220, 38, 38, 0.3)';
              }}
            >
              <FaPlay size={10} />
            </button>
          ) : (
            <span style={{ 
              color: '#94a3b8',
              fontSize: '14px',
              fontWeight: '500'
            }}>-</span>
          )}
        </td>

        {/* Notes Button */}
        <td style={{ 
          padding: '12px 16px', 
          textAlign: 'center',
          borderRight: '1px solid rgba(226, 232, 240, 0.2)'
        }}>
          {problem.notesLink ? (
            <a
              href={problem.notesLink}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                background: 'linear-gradient(135deg, #8b5cf6, #7c3aed)',
                color: 'white',
                padding: '8px 16px',
                borderRadius: '10px',
                textDecoration: 'none',
                fontSize: '13px',
                fontWeight: '600',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '6px',
                transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)', // ✨ Faster transition
                boxShadow: '0 4px 12px rgba(139, 92, 246, 0.3)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em'
              }}
              title="View notes"
              onMouseEnter={(e) => {
                e.target.style.transform = 'translateY(-2px)';
                e.target.style.boxShadow = '0 8px 20px rgba(139, 92, 246, 0.4)';
              }}
              onMouseLeave={(e) => {
                e.target.style.transform = 'translateY(0)';
                e.target.style.boxShadow = '0 4px 12px rgba(139, 92, 246, 0.3)';
              }}
            >
              <FaFileAlt size={10} />
            </a>
          ) : (
            <span style={{ 
              color: '#94a3b8',
              fontSize: '14px',
              fontWeight: '500'
            }}>-</span>
          )}
        </td>

        {/* Enhanced Practice Button */}
        <td style={{ 
          padding: '12px 16px', 
          textAlign: 'center',
          borderRight: '1px solid rgba(226, 232, 240, 0.2)'
        }}>
          {problem.practiceLink ? (
            <a
              href={problem.practiceLink}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                background: 'linear-gradient(135deg, #3b82f6, #2563eb)',
                color: 'white',
                padding: '8px 16px',
                borderRadius: '10px',
                textDecoration: 'none',
                fontSize: '13px',
                fontWeight: '600',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '6px',
                transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)', // ✨ Faster transition
                boxShadow: '0 4px 12px rgba(59, 130, 246, 0.3)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em'
              }}
              title="Solve on platform"
              onMouseEnter={(e) => {
                e.target.style.transform = 'translateY(-2px)';
                e.target.style.boxShadow = '0 8px 20px rgba(59, 130, 246, 0.4)';
              }}
              onMouseLeave={(e) => {
                e.target.style.transform = 'translateY(0)';
                e.target.style.boxShadow = '0 4px 12px rgba(59, 130, 246, 0.3)';
              }}
            >
              <FaExternalLinkAlt size={10} />
              Solve
            </a>
          ) : (
            <span style={{ 
              color: '#94a3b8',
              fontSize: '14px',
              fontWeight: '500'
            }}>-</span>
          )}
        </td>

        {/* Modern Difficulty Badge */}
        <td style={{ 
          padding: '12px 16px', 
          textAlign: 'center'
        }}>
          {problem.difficulty ? (
            <div style={{
              background: difficultyConfig.background,
              color: difficultyConfig.color,
              border: `1px solid ${difficultyConfig.border}`,
              padding: '6px 12px',
              borderRadius: '8px',
              fontSize: '12px',
              fontWeight: '700',
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px',
              backdropFilter: 'blur(10px)'
            }}>
              <span>{difficultyConfig.icon}</span>
              {problem.difficulty}
            </div>
          ) : (
            <span style={{ color: '#94a3b8' }}>-</span>
          )}
        </td>
      </tr>

      {/* Full-Screen Authentication Modal using Portal */}
      <AuthModal />

      {/* YouTube Modal Component */}
      <YouTubeModal
        videoUrl={problem.youtubeLink}
        isOpen={showVideo}
        onClose={() => setShowVideo(false)}
        problemName={problem.title} // Add this line
      />

      {/* ✨ OPTIMIZED: Faster animations */}
      <style jsx>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        @keyframes checkmark {
          0% { transform: scale(0) rotate(-45deg); }
          50% { transform: scale(1.2) rotate(-45deg); }
          100% { transform: scale(1) rotate(0deg); }
        }
        @keyframes fadeInScale {
          0% { 
            opacity: 0; 
            transform: scale(0.8);
          }
          100% { 
            opacity: 1; 
            transform: scale(1);
          }
        }
      `}</style>
    </>
  );
};

export default ProblemItem;
