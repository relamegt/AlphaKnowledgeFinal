import React, { useState, useEffect } from 'react';
import SubsectionView from './SubsectionView';
import { useProgress } from '../../hooks/useProgress';

const SectionView = ({ section, sheetId }) => {
  const { stats, refreshStats } = useProgress();
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    if (refreshStats) {
      refreshStats();
    }
  }, [refreshStats]);

  const getSectionProgress = () => {
    const totalProblems = section.subsections.reduce((total, subsection) => {
      return total + subsection.problems.length;
    }, 0);

    const completedProblems = stats.sectionStats?.[section.id] || 0;
    return { completed: completedProblems, total: totalProblems };
  };

  const progress = getSectionProgress();
  const percentage = progress.total > 0 ? Math.round((progress.completed / progress.total) * 100) : 0;

  return (
    <div className="section-container" style={{ 
      marginBottom: '2px',
      margin: '0 0 2px 0',
      padding: '0'
    }}>
      {/* Section Header */}
      <div 
        className="section-header"
        onClick={() => setIsExpanded(!isExpanded)}
        style={{ 
          cursor: 'pointer',
          padding: '20px 24px',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          borderRadius: isExpanded ? '16px 16px 0 0' : '16px',
          backgroundColor: 'rgba(255, 255, 255, 0.95)',
          backdropFilter: 'blur(10px)',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          background: `linear-gradient(135deg, 
            ${percentage === 100 ? 'rgba(34, 197, 94, 0.05)' : 'rgba(59, 130, 246, 0.05)'} 0%, 
            rgba(255, 255, 255, 0.95) 100%)`,
          border: `1px solid ${percentage === 100 ? 'rgba(34, 197, 94, 0.2)' : 'rgba(59, 130, 246, 0.2)'}`,
          position: 'relative',
          overflow: 'hidden',
          borderBottom: isExpanded ? 'none' : `1px solid ${percentage === 100 ? 'rgba(34, 197, 94, 0.2)' : 'rgba(59, 130, 246, 0.2)'}`,
          margin: '0'
        }}
      >
        <div style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: `linear-gradient(45deg, 
            ${percentage === 100 ? 'rgba(34, 197, 94, 0.02)' : 'rgba(59, 130, 246, 0.02)'} 0%, 
            transparent 50%, 
            ${percentage === 100 ? 'rgba(34, 197, 94, 0.02)' : 'rgba(59, 130, 246, 0.02)'} 100%)`,
          backgroundSize: '20px 20px',
          opacity: 0.5,
          zIndex: 0
        }} />

        <div style={{ display: 'flex', alignItems: 'center', gap: '16px', zIndex: 1 }}>
          <div style={{
            width: '40px',
            height: '40px',
            borderRadius: '10px',
            background: `linear-gradient(135deg, ${percentage === 100 ? '#22c55e' : '#3b82f6'}, ${percentage === 100 ? '#16a34a' : '#2563eb'})`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            fontSize: '16px',
            fontWeight: '600',
            transition: 'all 0.3s ease',
            transform: isExpanded ? 'rotate(90deg)' : 'rotate(0deg)',
            boxShadow: `0 4px 12px ${percentage === 100 ? 'rgba(34, 197, 94, 0.3)' : 'rgba(59, 130, 246, 0.3)'}`
          }}>
            ▶
          </div>
          
          <div>
            <h2 style={{ 
              margin: '0 0 4px 0', 
              fontSize: '22px', 
              fontWeight: '700',
              color: '#1e293b',
              letterSpacing: '-0.025em'
            }}>
              {section.name}
            </h2>
            <p style={{
              margin: 0,
              fontSize: '14px',
              color: '#64748b',
              fontWeight: '500'
            }}>
              {section.subsections.length} subsections • {progress.total} problems
            </p>
          </div>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px', zIndex: 1 }}>
          <div style={{
            position: 'relative',
            width: '60px',
            height: '60px',
            background: 'conic-gradient(' + 
              `${percentage === 100 ? '#22c55e' : '#3b82f6'} 0deg ` +
              `${percentage * 3.6}deg, ` +
              '#f1f5f9 ' + 
              `${percentage * 3.6}deg 360deg)`,
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <div style={{
              width: '46px',
              height: '46px',
              borderRadius: '50%',
              backgroundColor: 'white',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '12px',
              fontWeight: '700',
              color: percentage === 100 ? '#22c55e' : '#3b82f6'
            }}>
              {percentage}%
            </div>
          </div>
          
          <div style={{ textAlign: 'right' }}>
            <div style={{
              fontSize: '18px',
              fontWeight: '700',
              color: '#1e293b',
              marginBottom: '2px'
            }}>
              {progress.completed} / {progress.total}
            </div>
            <div style={{
              fontSize: '12px',
              color: percentage === 100 ? '#22c55e' : '#3b82f6',
              fontWeight: '600',
              textTransform: 'uppercase',
              letterSpacing: '0.05em'
            }}>
              {percentage === 100 ? 'COMPLETED' : 'IN PROGRESS'}
            </div>
          </div>
        </div>

        {percentage === 100 && (
          <div style={{
            position: 'absolute',
            top: '12px',
            right: '12px',
            background: 'linear-gradient(45deg, #22c55e, #16a34a)',
            color: 'white',
            padding: '4px 8px',
            borderRadius: '8px',
            fontSize: '10px',
            fontWeight: '700',
            textTransform: 'uppercase',
            letterSpacing: '0.05em',
            boxShadow: '0 2px 8px rgba(34, 197, 94, 0.4)'
          }}>
            ✓ DONE
          </div>
        )}
      </div>

      {/* Section Content - Add right padding for subsections */}
      {isExpanded && (
        <div className="section-content" style={{ 
          border: '1px solid rgba(255, 255, 255, 0.2)',
          borderTop: 'none',
          borderRadius: '0 0 16px 16px',
          backgroundColor: 'rgba(255, 255, 255, 0.98)',
          backdropFilter: 'blur(20px)',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.08)',
          overflow: 'hidden',
          margin: '0',
          padding: '0',
          marginTop: '0',
          paddingTop: '0',
          // Add right padding for subsection content[66][69]
          paddingRight: '20px' // Right padding only
        }}>
          {section.subsections.map((subsection, index) => (
            <div key={subsection.id} style={{
              margin: '0',
              padding: '0',
              // Ensure subsections inherit the right padding behavior
              width: '100%',
              boxSizing: 'border-box'
            }}>
              <SubsectionView
                subsection={subsection}
                sheetId={sheetId}
                sectionId={section.id}
                index={index}
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SectionView;
