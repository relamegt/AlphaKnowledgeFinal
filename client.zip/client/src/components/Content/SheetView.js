import React from 'react';
import SectionView from './SectionView';
import { useProgress } from '../../hooks/useProgress';

const SheetView = ({ sheet }) => {
  const { stats, getSheetDifficultyProgress } = useProgress(); // 🆕 Get new function

  const getSheetProgress = () => {
    const totalProblems = sheet.sections.reduce((total, section) => {
      return total + section.subsections.reduce((sectionTotal, subsection) => {
        return sectionTotal + subsection.problems.length;
      }, 0);
    }, 0);

    const completedProblems = stats.sheetStats?.[sheet.id] || 0;
    return { completed: completedProblems, total: totalProblems };
  };

  // 🆕 NEW: Calculate difficulty breakdown for the sheet
  const getDifficultyBreakdown = () => {
    const breakdown = { 
      Easy: { completed: 0, total: 0 }, 
      Medium: { completed: 0, total: 0 }, 
      Hard: { completed: 0, total: 0 } 
    };
    
    sheet.sections.forEach(section => {
      section.subsections.forEach(subsection => {
        subsection.problems.forEach(problem => {
          if (problem.difficulty && breakdown[problem.difficulty]) {
            breakdown[problem.difficulty].total++;
          }
        });
      });
    });
    
    // Get completed counts from stats
    breakdown.Easy.completed = getSheetDifficultyProgress(sheet.id, 'Easy');
    breakdown.Medium.completed = getSheetDifficultyProgress(sheet.id, 'Medium');
    breakdown.Hard.completed = getSheetDifficultyProgress(sheet.id, 'Hard');
    
    return breakdown;
  };

  const progress = getSheetProgress();
  const percentage = progress.total > 0 ? Math.round((progress.completed / progress.total) * 100) : 0;
  const difficultyBreakdown = getDifficultyBreakdown(); // 🆕 NEW

  return (
    <div className="sheet-view-container" style={{ 
      maxWidth: '1400px',
      margin: '0 auto',
      padding: '20px',
      minHeight: '100vh'
    }}>
      {/* Sheet Header */}
      <div className="sheet-header" style={{
        marginBottom: '24px',
        padding: '32px 24px',
        backgroundColor: '#f8fafc',
        borderRadius: '12px',
        border: '1px solid #e2e8f0',
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)'
      }}>
        {/* Title Section */}
        <div style={{
          textAlign: 'left',
          marginBottom: '24px'
        }}>
          <h1 style={{ 
            margin: '0 0 8px 0',
            fontSize: '32px',
            fontWeight: '700',
            color: '#1e293b',
            lineHeight: '1.2'
          }}>
            {sheet.name}
          </h1>
          {sheet.description && (
            <p style={{
              margin: '0',
              fontSize: '16px',
              color: '#64748b',
              fontWeight: '400'
            }}>
              {sheet.description}
            </p>
          )}
        </div>
        
        {/* Progress Section */}
        <div className="sheet-progress-display" style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '24px'
        }}>
          {/* Left side - Total Progress with colored circular indicator */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '20px'
          }}>
            <div style={{
              position: 'relative',
              width: '80px',
              height: '80px'
            }}>
              {/* Background Circle */}
              <div style={{
                position: 'absolute',
                inset: '0',
                borderRadius: '50%',
                backgroundColor: '#e2e8f0'
              }} />
              
              {/* Progress Circle */}
              <div style={{
                position: 'absolute',
                inset: '0',
                borderRadius: '50%',
                background: `conic-gradient(
                  ${percentage === 100 ? '#22c55e' : '#3b82f6'} 0deg ${percentage * 3.6}deg,
                  #e2e8f0 ${percentage * 3.6}deg 360deg
                )`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                {/* Inner White Circle */}
                <div style={{
                  width: '60px',
                  height: '60px',
                  borderRadius: '50%',
                  backgroundColor: 'white',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '14px',
                  fontWeight: '700',
                  color: percentage === 100 ? '#22c55e' : '#3b82f6'
                }}>
                  {percentage}%
                </div>
              </div>
            </div>
            
            <div>
              <div style={{
                fontSize: '14px',
                fontWeight: '600',
                color: '#64748b',
                marginBottom: '4px'
              }}>
                Total Progress
              </div>
              <div style={{
                fontSize: '24px',
                fontWeight: '700',
                color: '#1e293b'
              }}>
                {progress.completed} / {progress.total}
              </div>
            </div>
          </div>

          {/* Right side - Real Difficulty breakdown */}
          <div style={{
            display: 'flex',
            gap: '32px',
            alignItems: 'center'
          }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{
                fontSize: '14px',
                fontWeight: '600',
                color: '#22c55e',
                marginBottom: '4px'
              }}>
                Easy
              </div>
              <div style={{
                fontSize: '18px',
                fontWeight: '700',
                color: '#1e293b'
              }}>
                {difficultyBreakdown.Easy.completed} / {difficultyBreakdown.Easy.total} <span style={{ fontSize: '14px', fontWeight: '500', color: '#64748b' }}>completed</span>
              </div>
            </div>

            <div style={{ textAlign: 'center' }}>
              <div style={{
                fontSize: '14px',
                fontWeight: '600',
                color: '#f59e0b',
                marginBottom: '4px'
              }}>
                Medium
              </div>
              <div style={{
                fontSize: '18px',
                fontWeight: '700',
                color: '#1e293b'
              }}>
                {difficultyBreakdown.Medium.completed} / {difficultyBreakdown.Medium.total} <span style={{ fontSize: '14px', fontWeight: '500', color: '#64748b' }}>completed</span>
              </div>
            </div>

            <div style={{ textAlign: 'center' }}>
              <div style={{
                fontSize: '14px',
                fontWeight: '600',
                color: '#ef4444',
                marginBottom: '4px'
              }}>
                Hard
              </div>
              <div style={{
                fontSize: '18px',
                fontWeight: '700',
                color: '#1e293b'
              }}>
                {difficultyBreakdown.Hard.completed} / {difficultyBreakdown.Hard.total} <span style={{ fontSize: '14px', fontWeight: '500', color: '#64748b' }}>completed</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* All Sections */}
      <div className="sections-container" style={{
        display: 'flex',
        flexDirection: 'column',
        width: '100%'
      }}>
        {sheet.sections.map(section => (
          <div key={section.id} style={{
            width: '100%',
            boxSizing: 'border-box'
          }}>
            <SectionView
              section={section}
              sheetId={sheet.id}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default SheetView;
