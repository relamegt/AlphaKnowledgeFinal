import React, { createContext, useState, useEffect, useCallback } from 'react';
import { progressAPI } from '../services/api';
import { useAuth } from './AuthContext';

export const ProgressContext = createContext();

export const ProgressProvider = ({ children }) => {
  const { user } = useAuth();
  const [progress, setProgress] = useState([]);
  const [stats, setStats] = useState({
    totalCompleted: 0,
    sheetStats: {},
    sectionStats: {},
    subsectionStats: {},
    difficultyStats: { // 🆕 NEW
      Easy: 0,
      Medium: 0,
      Hard: 0
    },
    sheetDifficultyStats: {}, // 🆕 NEW
    recentActivity: []
  });
  const [loading, setLoading] = useState(false);

  // Fetch user progress
  const fetchProgress = useCallback(async () => {
    if (!user) {
      setProgress([]);
      return;
    }
    
    try {
      setLoading(true);
      const response = await progressAPI.getUserProgress(user.id);
      setProgress(response.data || []);
    } catch (error) {
      console.error('Error fetching progress:', error);
      setProgress([]);
    } finally {
      setLoading(false);
    }
  }, [user]);

  // Fetch statistics (now includes subsection and difficulty stats)
  const fetchStats = useCallback(async () => {
    if (!user) {
      setStats({ 
        totalCompleted: 0,
        sheetStats: {}, 
        sectionStats: {}, 
        subsectionStats: {},
        difficultyStats: { Easy: 0, Medium: 0, Hard: 0 }, // 🆕 NEW
        sheetDifficultyStats: {}, // 🆕 NEW
        recentActivity: []
      });
      return;
    }

    try {
      const response = await progressAPI.getStats(user.id);
      setStats(response.data || { 
        totalCompleted: 0,
        sheetStats: {}, 
        sectionStats: {}, 
        subsectionStats: {},
        difficultyStats: { Easy: 0, Medium: 0, Hard: 0 }, // 🆕 NEW
        sheetDifficultyStats: {}, // 🆕 NEW
        recentActivity: []
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
      setStats({ 
        totalCompleted: 0,
        sheetStats: {}, 
        sectionStats: {}, 
        subsectionStats: {},
        difficultyStats: { Easy: 0, Medium: 0, Hard: 0 }, // 🆕 NEW
        sheetDifficultyStats: {}, // 🆕 NEW
        recentActivity: []
      });
    }
  }, [user]);

  // Refresh all data
  const refreshStats = useCallback(async () => {
    await Promise.all([fetchProgress(), fetchStats()]);
  }, [fetchProgress, fetchStats]);

  // Auto-fetch when user changes
  useEffect(() => {
    if (user) {
      fetchProgress();
      fetchStats();
    } else {
      setProgress([]);
      setStats({ 
        totalCompleted: 0,
        sheetStats: {}, 
        sectionStats: {}, 
        subsectionStats: {},
        difficultyStats: { Easy: 0, Medium: 0, Hard: 0 }, // 🆕 NEW
        sheetDifficultyStats: {}, // 🆕 NEW
        recentActivity: []
      });
    }
  }, [user, fetchProgress, fetchStats]);

  // Toggle problem completion
  const toggleProblem = async (problemData) => {
    if (!user) return false;
    try {
      const response = await progressAPI.toggleProblem({
        ...problemData,
        difficulty: problemData.difficulty, // 🆕 Pass difficulty
        userId: user.id
      });
      console.log('Toggle response:', response);
      if (response.data.success) {
        // Update local progress state
        const existingIndex = progress.findIndex(p => p.problemId === problemData.problemId);
        if (existingIndex >= 0) {
          const newProgress = [...progress];
          newProgress[existingIndex] = response.data.progress;
          setProgress(newProgress);
        } else {
          setProgress([...progress, response.data.progress]);
        }

        // Refresh stats after toggle to get updated counts
        await fetchStats();
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error toggling problem:', error);
      return false;
    }
  };

  // Check if problem is completed
  const isProblemCompleted = (problemId) => {
    return progress.some(p => p.problemId === problemId && p.isCompleted);
  };

  // Get subsection progress
  const getSubsectionProgress = (subsectionId) => {
    return stats.subsectionStats[subsectionId] || 0;
  };

  // Get section progress
  const getSectionProgress = (sectionId) => {
    return stats.sectionStats[sectionId] || 0;
  };

  // Get sheet progress
  const getSheetProgress = (sheetId) => {
    return stats.sheetStats[sheetId] || 0;
  };

  // 🆕 NEW: Get difficulty-specific progress for a sheet
  const getSheetDifficultyProgress = (sheetId, difficulty) => {
    return stats.sheetDifficultyStats?.[sheetId]?.[difficulty] || 0;
  };

  // Context value
  const value = {
    progress,
    stats,
    loading,
    toggleProblem,
    isProblemCompleted,
    getSubsectionProgress,
    getSectionProgress,
    getSheetProgress,
    getSheetDifficultyProgress, // 🆕 NEW
    fetchProgress,
    fetchStats,
    refreshStats
  };

  return (
    <ProgressContext.Provider value={value}>
      {children}
    </ProgressContext.Provider>
  );
};
