import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate, useParams } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ProgressProvider } from './context/ProgressContext';
import { ThemeProvider } from './context/ThemeContext';
import Header from './components/Common/Header';
import Home from './components/Pages/Home';
import SheetList from './components/Content/SheetList';
import SheetView from './components/Content/SheetView';
import ContactUs from './components/Pages/ContactUs';
import MainLayout from './components/Layout/MainLayout';
import contentData from './data/content.json';
import './App.css';

// Main App Component with Routing
function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <ProgressProvider>
          <Router>
            <div className="App">
              <Routes>
                {/* Home route */}
                <Route path="/" element={<HomePage />} />
                
                {/* Sheets routes */}
                <Route path="/sheets" element={<SheetsPage />} />
                <Route path="/sheet/:sheetId" element={<SheetDetailsPage />} />
                
                {/* Contact Us route */}
                <Route path="/contact" element={<ContactUsPage />} />
                
                {/* Fallback route */}
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
            </div>
          </Router>
        </ProgressProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

// Home Page Component
function HomePage() {
  return (
    <MainLayout showSidebar={false}>
      <Home />
    </MainLayout>
  );
}

// Sheets Page Component  
function SheetsPage() {
  const navigate = useNavigate();
  const [content] = useState(contentData);

  const handleSheetSelect = (sheetId) => {
    navigate(`/sheet/${sheetId}`);
  };

  return (
    <MainLayout 
      content={content}
      showSidebar={false}
    >
      <SheetList
        content={content}
        onSheetSelect={handleSheetSelect}
      />
    </MainLayout>
  );
}

// Sheet Details Page Component
function SheetDetailsPage() {
  const navigate = useNavigate();
  const { sheetId } = useParams();
  const [content] = useState(contentData);
  const [selectedSection, setSelectedSection] = useState(null);

  const handleBackToSheets = () => {
    navigate('/sheets');
  };

  const getCurrentSheet = () => {
    return content.sheets.find(sheet => sheet.id === sheetId);
  };

  const handleSheetSelect = (newSheetId) => {
    navigate(`/sheet/${newSheetId}`);
  };

  const handleSectionSelect = (sectionId) => {
    setSelectedSection(sectionId);
  };

  const sheet = getCurrentSheet();

  if (!sheet) {
    return (
      <MainLayout showSidebar={false}>
        <div className="not-found-container">
          <h2>Sheet not found</h2>
          <button 
            onClick={handleBackToSheets}
            className="btn-primary"
          >
            Back to All Sheets
          </button>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout 
      content={content}
      selectedSheet={sheetId}
      selectedSection={selectedSection}
      onSheetSelect={handleSheetSelect}
      onSectionSelect={handleSectionSelect}
      showSidebar={true}
    >
      <SheetView sheet={sheet} />
    </MainLayout>
  );
}

// Contact Us Page Component
function ContactUsPage() {
  return (
    <MainLayout showSidebar={false}>
      <ContactUs />
    </MainLayout>
  );
}

// 404 Not Found Page
function NotFoundPage() {
  const navigate = useNavigate();

  return (
    <MainLayout showSidebar={false}>
      <div className="not-found-page">
        <div className="not-found-content">
          <h1>404</h1>
          <h2>Page Not Found</h2>
          <p>The page you're looking for doesn't exist.</p>
          <button 
            onClick={() => navigate('/')}
            className="btn-primary"
          >
            Go Home
          </button>
        </div>
      </div>
    </MainLayout>
  );
}

export default App;
